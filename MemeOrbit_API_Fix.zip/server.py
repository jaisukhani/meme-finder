#!/usr/bin/env python3
"""
MemeOrbit local web server + same-origin API proxy.
Run: python server.py
Then open http://127.0.0.1:8000
Requires Python 3.9+. Uses only the standard library.
"""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from pathlib import Path
import json

HOST = "127.0.0.1"
PORT = 8000
UPSTREAM_API = "https://findthatmeme.com/api/v1/search"
ROOT = Path(__file__).resolve().parent

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_GET(self):
        if self.path == "/":
            self.path = "/findthatmeme_clone_fixed.html"
        return super().do_GET()

    def do_POST(self):
        if self.path.rstrip("/") != "/api/search":
            self.send_error(404, "Not found")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 1_000_000:
                self.send_error(400, "Invalid request body")
                return
            raw = self.rfile.read(length)
            payload = json.loads(raw.decode("utf-8"))
            query = str(payload.get("search", "")).strip()
            try:
                offset = max(0, int(payload.get("offset", 0)))
            except (TypeError, ValueError):
                offset = 0
            if not query:
                self.send_json(400, {"error": "Search phrase is required"})
                return

            upstream_body = json.dumps({"search": query, "offset": offset}).encode("utf-8")
            request = Request(
                UPSTREAM_API,
                data=upstream_body,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "User-Agent": "MemeOrbit/1.0"
                },
                method="POST"
            )
            with urlopen(request, timeout=15) as response:
                data = response.read()
                content_type = response.headers.get("Content-Type", "application/json")
                if response.status < 200 or response.status >= 300:
                    self.send_json(502, {"error": "Upstream search service returned an error"})
                    return
                # Validate JSON before relaying it to the browser.
                parsed = json.loads(data.decode("utf-8"))
                if not isinstance(parsed, list):
                    self.send_json(502, {"error": "Unexpected response from upstream search service"})
                    return
                self.send_response(200)
                self.send_header("Content-Type", content_type if "json" in content_type else "application/json")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1:8000")
                self.end_headers()
                self.wfile.write(json.dumps(parsed).encode("utf-8"))
        except HTTPError as exc:
            self.send_json(502, {"error": f"Upstream search service returned HTTP {exc.code}"})
        except (URLError, TimeoutError) as exc:
            self.send_json(502, {"error": "Could not connect to the upstream meme index. It may be offline or unreachable."})
        except (json.JSONDecodeError, UnicodeDecodeError):
            self.send_json(400, {"error": "Invalid JSON request"})
        except Exception:
            self.send_json(500, {"error": "Unexpected server error"})

    def send_json(self, status, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        # Keep routine requests readable without exposing query content.
        print("%s - %s" % (self.address_string(), fmt % args))

if __name__ == "__main__":
    print(f"MemeOrbit running at http://{HOST}:{PORT}")
    print("Keep this terminal open while using the site. Press Ctrl+C to stop.")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
